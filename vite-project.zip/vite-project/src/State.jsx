import React, { useState } from 'react'

export default function State() {
    let [count,setCount] = useState(1);
    // count --> state name
    // setCount --> state functiion that updates the statte value
    // 1 is count default value
    let changeState=()=>{
        setCount(count+2)
    }
  return (
    <div><h1>State</h1>
        {count}
        <button onClick={changeState}> Chnage State</button>
    </div>
  )
}
