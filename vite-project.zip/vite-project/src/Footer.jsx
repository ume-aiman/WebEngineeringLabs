import React from 'react'

export default function Footer() {
  return (
    <div><h1>Ewlcome to Footer Section </h1></div>
  )
}
