import React, { useState } from 'react';

const StepForm = () => {
  const initialSteps = { step1: false, step2: false, step3: false, step4: false };
  const [userSteps, setUserSteps] = useState([]);
  const [activeUser, setActiveUser] = useState(null);
  //const [previousUser , setPreviousUser] = useState(null)

  const addUser = () => {
    setUserSteps([...userSteps, { ...initialSteps }]);
    if (activeUser === null) {
      setActiveUser(0); 
    }
  };

  const handleStepChange = (userIndex, step) => {
    const updatedUserSteps = [...userSteps];
    updatedUserSteps[userIndex][step] = true;

    setUserSteps(updatedUserSteps);
  };

  const resetUserSteps = (userIndex) => {
    const updatedUserSteps = [...userSteps];
    updatedUserSteps[userIndex] = { ...initialSteps };

    setUserSteps(updatedUserSteps);
  };
   const previousUser=(userIndex) =>{
     updatedUser(activeUser+1)
     updatedUser(previousUser+1)

   }
  const handleNextUser = () => {
    if (activeUser < userSteps.length - 1) {
      resetUserSteps(activeUser); 
      setActiveUser(activeUser + 1); 
    }
  };

  return (
    <div>
      <button onClick={addUser}>Create User</button>
      {userSteps.map((user, userIndex) => (
        <div key={userIndex} style={{ marginBottom: '20px' }}>
          <h2>User {userIndex + 1}</h2>
          {Object.keys(user).map((step, stepIndex) => (
            <button
              key={stepIndex}
              disabled={activeUser !== userIndex}
              onClick={() => handleStepChange(userIndex, step)}
              style={{ backgroundColor: user[step] ? 'green' : 'grey', marginRight: '10px' }}
            >
              {step}
            </button>
          ))}
          {userIndex === activeUser && user.step3 && (
            <button onClick={handleNextUser}>Next</button>
          )}
        </div>
      ))}
    </div>
  );
};

export default StepForm;
